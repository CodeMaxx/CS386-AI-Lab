#! /bin/bash

python3 value_iteration.py $1
