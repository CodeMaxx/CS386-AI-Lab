#! /bin/bash

python3 encoder.py $1
